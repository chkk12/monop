function lancerDe() {
    return Math.floor(Math.random() * 6) + 1;
}

function lancerLesDes() {
    const resultat = lancerDe();
    
    document.getElementById('dice1').querySelector('.dice-face').textContent = resultat;
    
    console.log('Résultat du dé :', resultat);
}

document.addEventListener('DOMContentLoaded', function() {
    const boutonLancer = document.getElementById('rollDice');
    if (boutonLancer) {
        boutonLancer.addEventListener('click', lancerLesDes);
    }
});
